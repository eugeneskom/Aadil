/// <reference types="react-scripts" />
NOTION_ACCOUNT_SID = "IRjdLjoN3riD2397250hvx9sTMntgAkwi1"
NOTION_AUTH_TOKEN = "nyfobSWRcYZNEs-HZNYrngMz55bjB-Kf"
