export interface UserType {
  _id: string;
  email: string;
  googleId: string;
  isAdmin: boolean;
  createdAt: string;
  updatedAt: string;
  __v: number;
}
