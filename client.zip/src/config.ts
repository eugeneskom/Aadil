export const accountSID = 'IRjdLjoN3riD2397250hvx9sTMntgAkwi1';
export const authToken = 'nyfobSWRcYZNEs-HZNYrngMz55bjB-Kf';
export const apiUrlDomain = 'http://localhost:3001'